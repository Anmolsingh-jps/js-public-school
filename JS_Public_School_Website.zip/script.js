window.onload = function () {
  console.log("Welcome to JS Public School Website (2019)");
};
